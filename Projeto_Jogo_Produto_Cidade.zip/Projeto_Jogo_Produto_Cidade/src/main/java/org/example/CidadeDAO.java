package org.example;

import java.util.List;

public interface CidadeDAO {
    boolean create (Cidade cidade);
    List <Cidade> read();
    boolean update(Cidade cidade);
    boolean delete(Cidade cidade);
    boolean readNomeCidade(Cidade cidade);
}
