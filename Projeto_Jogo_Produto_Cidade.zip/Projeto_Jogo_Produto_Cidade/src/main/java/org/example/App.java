package org.example;
//Beatriz Novais - Tia: 31951155
//Mariana Gonçalves - Tia: 31912362
//Giullia Nannini - Tia: 31887759
public class App {
    public static void main(final String[] args) {
        ProdutoDAOMySQL mysqlDAO = new ProdutoDAOMySQL();
        JogoDAOMySQL mysqlDAO1 = new JogoDAOMySQL();
        CidadeDAOMySQL mysqlDAO2 = new CidadeDAOMySQL();
        InterfaceUsuario interfaceUsuario = new InterfaceUsuario(mysqlDAO, mysqlDAO1, mysqlDAO2 );
        interfaceUsuario.iniciar();
    }
}
