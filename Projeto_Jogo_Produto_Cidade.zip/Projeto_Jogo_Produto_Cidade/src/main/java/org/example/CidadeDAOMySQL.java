package org.example;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CidadeDAOMySQL implements CidadeDAO {
    private String createSQL = "INSERT INTO cidade VALUES (?, ?, ?, ?)";
    private String readSQL = "SELECT * FROM cidade";
    private String updateSQL = "UPDATE cidade SET populacao=?";
    private String deleteSQL = "DELETE FROM cidade WHERE nome_cidade=?";
    private String readNomeCidadeSQL = "SELECT * FROM cidade WHERE nome_cidade=?  ";

    private final MySQLConnection mysql = new MySQLConnection();

    public boolean create(Cidade cidade) {
        Connection conexao = mysql.getConnection();
        try {
            PreparedStatement stm = conexao.prepareStatement(createSQL);

            stm.setString(1, cidade.getNomeCidade());
            stm.setString(2, cidade.getEstado());
            stm.setString(3, cidade.getPais());
            stm.setInt(4, cidade.getPopulacao());

            int registros = stm.executeUpdate();
            return registros > 0 ? true : false;

        } catch (final SQLException ex) {
            System.out.println("Falha de conexão com a base de dados!");
            ex.printStackTrace();
        } catch (final Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                conexao.close();
            } catch (final Exception ex) {
                ex.printStackTrace();
            }
        }
        return false;
    }

    @Override
    public List<Cidade> read() {
        Connection conexao = mysql.getConnection();
        List<Cidade> cidades = new ArrayList();

        try {
            PreparedStatement stm = conexao.prepareStatement(readSQL);
            ResultSet rs = stm.executeQuery();

            while (rs.next()) {
                Cidade cidade = new Cidade();
                cidade.setNomeCidade(rs.getString("nome_cidade"));
                cidade.setEstado(rs.getString("nome_estado"));
                cidade.setPais(rs.getString("nome_pais"));
                cidade.setPopulacao(rs.getInt("populacao"));
                cidades.add(cidade);
            }

            return cidades;

        } catch (final SQLException ex) {
            System.out.println("Falha de conexão com a base de dados!");
            ex.printStackTrace();
        } catch (final Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                conexao.close();
            } catch (final Exception ex) {
                ex.printStackTrace();
            }
        }
        return cidades;
    }

    @Override
    public boolean update(Cidade cidade) {
        Connection conexao = mysql.getConnection();
        try {
            PreparedStatement stm = conexao.prepareStatement(updateSQL);

            stm.setInt(1, cidade.getPopulacao());

            int registros = stm.executeUpdate();
            return registros > 0 ? true : false;

        } catch (final SQLException ex) {
            System.out.println("Falha de conexão com a base de dados!");
            ex.printStackTrace();
        } catch (final Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                conexao.close();
            } catch (final Exception ex) {
                ex.printStackTrace();
            }
        }
        return false;
    }

    @Override
    public boolean delete(Cidade cidade) {
        Connection conexao = mysql.getConnection();
        try {
            PreparedStatement stm = conexao.prepareStatement(deleteSQL);

            stm.setString(1, cidade.getNomeCidade());

            int registros = stm.executeUpdate();

            return registros > 0 ? true : false;

        } catch (final SQLException ex) {
            System.out.println("Falha de conexão com a base de dados!");
            ex.printStackTrace();
        } catch (final Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                conexao.close();
            } catch (final Exception ex) {
                ex.printStackTrace();
            }
        }
        return false;
    }

    @Override
    public boolean readNomeCidade(Cidade cidade) {
        Connection conexao = mysql.getConnection();

        try {
            PreparedStatement stm = conexao.prepareStatement(readNomeCidadeSQL);
            stm.setString(1, cidade.getNomeCidade());
            ResultSet rs = stm.executeQuery();

            while (rs.next()) {

                cidade.setNomeCidade(rs.getString("nome_cidade"));
                cidade.setEstado(rs.getString("nome_estado"));
                cidade.setPais(rs.getString("nome_pais"));
                cidade.setPopulacao(rs.getInt("populacao"));

                System.out.println(cidade);
            }


        } catch (final SQLException ex) {
            System.out.println("Falha de conexão com a base de dados!");
            ex.printStackTrace();
        } catch (final Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                conexao.close();
            } catch (final Exception ex) {
                ex.printStackTrace();
            }
        }
        return false;
    }
}
    
