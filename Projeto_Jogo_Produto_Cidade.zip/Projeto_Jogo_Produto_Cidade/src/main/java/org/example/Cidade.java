package org.example;

public class Cidade {
    private String nomeCidade;
    private String estado;
    private String pais;
    private int populacao;

    public Cidade() {}

    public String getNomeCidade() {
        return nomeCidade;
    }

    public void setNomeCidade(String nomeCidade) {
        this.nomeCidade = nomeCidade;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public int getPopulacao() {
        return populacao;
    }

    public void setPopulacao(int populacao) {
        this.populacao = populacao;
    }

    @Override
    public String toString() {
        return "\nNome da Cidade: " + nomeCidade +
                "\nNome do Estado: " + estado + "\nPais: " + pais + "\nPopulação: " + populacao +
                "\n----------------------------------";
    }
}

