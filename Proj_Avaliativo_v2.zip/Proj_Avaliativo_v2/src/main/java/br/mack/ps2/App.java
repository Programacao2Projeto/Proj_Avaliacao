package br.mack.ps2;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        ProdutoDAOMySql mysqlDAO = new ProdutoDAOMySql();
        JogoDAOMySql mysqlDAO1 = new JogoDAOMySql();
        InterfaceUsuario interfaceUsuario = new InterfaceUsuario(mysqlDAO, mysqlDAO1);
        interfaceUsuario.iniciar();

    }
}
